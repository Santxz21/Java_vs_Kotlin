package com.example.todolist

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Calendar

data class User(val id: Long, val username: String, var name: String, var email: String)

data class Task(
    var id: Long,
    var title: String,
    var description: String,
    var date: String,      // formato ISO: yyyy-MM-dd
    var time: String,      // formato 24h: HH:mm (puede ir vacío)
    var priority: String,
    var category: String,
    var done: Boolean = false
)

/** Utilidades de fecha. Las fechas se guardan como yyyy-MM-dd para poder ordenarlas y ubicarlas en el calendario. */
object Dates {
    private val shortMonths = listOf("ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic")
    val months = listOf(
        "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
        "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
    )

    fun iso(y: Int, m0: Int, d: Int): String = String.format("%04d-%02d-%02d", y, m0 + 1, d)

    fun shift(days: Int): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_MONTH, days)
        return iso(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
    }

    fun today(): String = shift(0)

    fun pretty(iso: String): String {
        if (iso == today()) return "Hoy"
        if (iso == shift(1)) return "Mañana"
        val p = iso.split("-")
        if (p.size != 3) return iso
        val thisYear = Calendar.getInstance().get(Calendar.YEAR)
        val base = "${p[2].toInt()} ${shortMonths[p[1].toInt() - 1]}"
        return if (p[0].toInt() != thisYear) "$base ${p[0]}" else base
    }

    fun long(iso: String): String {
        val p = iso.split("-")
        if (p.size != 3) return iso
        return "${p[2].toInt()} de ${months[p[1].toInt() - 1].lowercase()} de ${p[0]}"
    }

    fun time(t: String): String {
        if (t.isBlank()) return ""
        val p = t.split(":")
        val h = p[0].toInt()
        val m = p[1].toInt()
        val h12 = if (h % 12 == 0) 12 else h % 12
        return String.format("%d:%02d %s", h12, m, if (h >= 12) "PM" else "AM")
    }
}

/** Base de datos local (SQLite). Contiene los usuarios y las tareas de cada usuario. */
class TodoDb(ctx: Context) : SQLiteOpenHelper(ctx, "todolist.db", null, 1) {

    companion object {
        const val ADMIN_USER = "Admin123"
        const val ADMIN_PASS = "pepe"
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE users(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                email TEXT NOT NULL,
                salt TEXT NOT NULL,
                password_hash TEXT NOT NULL)"""
        )
        db.execSQL(
            """CREATE TABLE tasks(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                title TEXT NOT NULL,
                description TEXT NOT NULL DEFAULT '',
                date TEXT NOT NULL,
                time TEXT NOT NULL DEFAULT '',
                priority TEXT NOT NULL,
                category TEXT NOT NULL,
                done INTEGER NOT NULL DEFAULT 0)"""
        )
        db.execSQL("CREATE INDEX idx_tasks_user_date ON tasks(user_id, date)")

        // Usuario administrador predefinido
        val adminId = insertUser(db, ADMIN_USER, "Administrador", "admin@todolist.com", ADMIN_PASS)
        if (adminId > 0) seedTasks(db, adminId)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    // ---------- Seguridad de contraseñas ----------

    private fun newSalt(): String {
        val b = ByteArray(16)
        SecureRandom().nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    private fun hash(password: String, salt: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest((salt + password).toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    private fun matches(password: String, salt: String, stored: String): Boolean =
        MessageDigest.isEqual(hash(password, salt).toByteArray(), stored.toByteArray())

    // ---------- Usuarios ----------

    private fun insertUser(db: SQLiteDatabase, username: String, name: String, email: String, password: String): Long {
        val salt = newSalt()
        val v = ContentValues().apply {
            put("username", username)
            put("name", name)
            put("email", email)
            put("salt", salt)
            put("password_hash", hash(password, salt))
        }
        return db.insert("users", null, v)
    }

    /** Devuelve el usuario solo si usuario Y contraseña coinciden EXACTAMENTE (distingue mayúsculas y minúsculas). */
    fun login(username: String, password: String): User? {
        if (username.isEmpty() || password.isEmpty()) return null
        return readableDatabase.rawQuery(
            "SELECT id, username, name, email, salt, password_hash FROM users WHERE username = ?",
            arrayOf(username)
        ).use { c ->
            if (!c.moveToFirst()) null
            else if (c.getString(1) != username) null // comparación exacta, sin importar el collation
            else if (!matches(password, c.getString(4), c.getString(5))) null
            else User(c.getLong(0), c.getString(1), c.getString(2), c.getString(3))
        }
    }

    /** Crea un usuario nuevo (el correo se usa como nombre de usuario). Devuelve null si ya existe. */
    fun register(name: String, email: String, password: String): User? {
        val id = insertUser(writableDatabase, email, name, email, password)
        return if (id > 0) User(id, email, name, email) else null
    }

    fun updateProfile(id: Long, name: String, email: String): Boolean {
        val v = ContentValues().apply { put("name", name); put("email", email) }
        return writableDatabase.update("users", v, "id = ?", arrayOf(id.toString())) > 0
    }

    fun changePassword(id: Long, current: String, new: String): Boolean {
        val ok = readableDatabase.rawQuery(
            "SELECT salt, password_hash FROM users WHERE id = ?", arrayOf(id.toString())
        ).use { c -> c.moveToFirst() && matches(current, c.getString(0), c.getString(1)) }
        if (!ok) return false
        val salt = newSalt()
        val v = ContentValues().apply { put("salt", salt); put("password_hash", hash(new, salt)) }
        return writableDatabase.update("users", v, "id = ?", arrayOf(id.toString())) > 0
    }

    // ---------- Tareas ----------

    fun tasks(userId: Long): MutableList<Task> {
        val out = mutableListOf<Task>()
        readableDatabase.rawQuery(
            "SELECT id, title, description, date, time, priority, category, done FROM tasks " +
                "WHERE user_id = ? ORDER BY done, date, time, id",
            arrayOf(userId.toString())
        ).use { c ->
            while (c.moveToNext()) {
                out.add(Task(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5), c.getString(6), c.getInt(7) == 1))
            }
        }
        return out
    }

    private fun values(userId: Long?, t: Task) = ContentValues().apply {
        if (userId != null) put("user_id", userId)
        put("title", t.title)
        put("description", t.description)
        put("date", t.date)
        put("time", t.time)
        put("priority", t.priority)
        put("category", t.category)
        put("done", if (t.done) 1 else 0)
    }

    fun insertTask(userId: Long, t: Task): Long {
        val id = writableDatabase.insert("tasks", null, values(userId, t))
        t.id = id
        return id
    }

    fun updateTask(t: Task) {
        writableDatabase.update("tasks", values(null, t), "id = ?", arrayOf(t.id.toString()))
    }

    fun deleteTask(id: Long) {
        writableDatabase.delete("tasks", "id = ?", arrayOf(id.toString()))
    }

    private fun seedTasks(db: SQLiteDatabase, userId: Long) {
        val samples = listOf(
            Task(0, "Terminar proyecto de la uni", "Revisar el documento final, corregir los errores y subirlo a la plataforma.", Dates.shift(0), "10:00", "Alta", "Escuela"),
            Task(0, "Ir al gimnasio", "", Dates.shift(0), "18:00", "Media", "Personal"),
            Task(0, "Comprar víveres", "", Dates.shift(0), "20:00", "Baja", "Compras"),
            Task(0, "Leer un libro", "Terminar el capítulo 4 del libro que estoy leyendo.", Dates.shift(3), "19:00", "Media", "Personal"),
            Task(0, "Estudiar para el examen", "", Dates.shift(5), "10:00", "Alta", "Escuela"),
            Task(0, "Hacer tarea de programación", "", Dates.shift(-2), "", "Baja", "Escuela", true),
            Task(0, "Lavar la ropa", "", Dates.shift(-3), "", "Baja", "Personal", true),
            Task(0, "Pagar suscripción", "", Dates.shift(-4), "", "Media", "Trabajo", true)
        )
        samples.forEach { db.insert("tasks", null, values(userId, it)) }
    }
}
