package com.example.todolist

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.Patterns
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

class MainActivity : androidx.appcompat.app.AppCompatActivity() {

    // ---------- Paleta (cambia con el tema claro/oscuro) ----------
    private var bg = Color.rgb(10, 16, 34)
    private var card = Color.rgb(28, 37, 67)
    private var edge = Color.rgb(48, 59, 99)
    private var white = Color.rgb(245, 246, 252)
    private var muted = Color.rgb(158, 169, 197)
    private var navBg = Color.rgb(16, 23, 47)
    private val purple = Color.rgb(99, 96, 242)
    private val red = Color.rgb(239, 63, 75)
    private val green = Color.rgb(33, 190, 112)

    private val cats = listOf("Escuela", "Trabajo", "Personal", "Compras")

    // ---------- Datos / estado ----------
    private val db by lazy { TodoDb(this) }
    private val prefs by lazy { getSharedPreferences("todolist_prefs", Context.MODE_PRIVATE) }
    private var user: User? = null
    private var tasks: MutableList<Task> = mutableListOf()

    private var screen = "login"
    private var selected: Task? = null
    private var editing = false
    private var filter = "Todas"
    private var dark = true

    private val now = Calendar.getInstance()
    private var month = now.get(Calendar.MONTH)
    private var year = now.get(Calendar.YEAR)
    private var selDay = Dates.today()   // día elegido en el calendario
    private var presetDate = Dates.today() // fecha por defecto al crear tarea

    // ---------- Helpers de UI ----------
    private fun d(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun shape(c: Int, r: Int = 14, stroke: Int = 0) = GradientDrawable().apply {
        setColor(c)
        cornerRadius = d(r).toFloat()
        if (stroke != 0) setStroke(d(1), stroke)
    }

    private fun txt(s: String, z: Float = 15f, c: Int = white, b: Boolean = false) = TextView(this).apply {
        text = s
        textSize = z
        setTextColor(c)
        if (b) setTypeface(null, Typeface.BOLD)
    }

    private fun body(p: Int = 20) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(d(p), d(8), d(p), d(14))
        setBackgroundColor(bg)
    }

    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun gap(v: LinearLayout, n: Int = 10) {
        v.addView(View(this), LinearLayout.LayoutParams(1, d(n)))
    }

    private fun btn(s: String, on: () -> Unit, color: Int = card, fg: Int? = null, h: Int = 50): TextView {
        val textColor = fg ?: if (color == card) white else Color.WHITE
        return txt(s, 15f, textColor, true).apply {
            gravity = Gravity.CENTER
            background = shape(color, 14, if (color == card) edge else 0)
            setOnClickListener { on() }
            layoutParams = LinearLayout.LayoutParams(-1, d(h)).apply { bottomMargin = d(9) }
        }
    }

    private fun field(h: String, v: String = "", type: Int = InputType.TYPE_CLASS_TEXT) = EditText(this).apply {
        hint = h
        setText(v)
        setHintTextColor(muted)
        setTextColor(white)
        textSize = 15f
        inputType = type
        background = shape(card, 14, edge)
        setPadding(d(15), d(8), d(15), d(8))
        minHeight = d(50)
    }

    private val passType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun dialogForm(title: String, fields: List<EditText>, okText: String, onOk: () -> Boolean) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(20), d(10), d(20), 0)
        }
        fields.forEach { box.addView(it, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = d(8) }) }
        val dlg = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton(okText, null)
            .setNegativeButton("Cancelar", null)
            .create()
        // Se sobreescribe el click para que el diálogo no se cierre si hay errores de validación
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { if (onOk()) dlg.dismiss() }
        }
        dlg.show()
    }

    // ---------- Tema ----------
    private fun applyPalette() {
        if (dark) {
            bg = Color.rgb(10, 16, 34); card = Color.rgb(28, 37, 67); edge = Color.rgb(48, 59, 99)
            white = Color.rgb(245, 246, 252); muted = Color.rgb(158, 169, 197); navBg = Color.rgb(16, 23, 47)
        } else {
            bg = Color.rgb(243, 245, 252); card = Color.WHITE; edge = Color.rgb(214, 220, 238)
            white = Color.rgb(20, 26, 48); muted = Color.rgb(100, 110, 140); navBg = Color.WHITE
        }
        window.statusBarColor = bg
        window.navigationBarColor = bg
        androidx.core.view.WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = !dark
            isAppearanceLightNavigationBars = !dark
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, true)
        dark = prefs.getBoolean("dark", true)
        applyPalette()
        show("login")
    }

    private fun reload() {
        tasks = user?.let { db.tasks(it.id) } ?: mutableListOf()
    }

    private fun show(s: String) {
        if (user == null && s != "login" && s != "register") {
            screen = "login"; login(); return
        }
        screen = s
        when (s) {
            "login" -> login()
            "register" -> register()
            "home" -> home()
            "tasks" -> taskList()
            "add" -> form()
            "detail" -> detail()
            "categories" -> categories()
            "calendar" -> calendar()
            "profile" -> profile()
        }
    }

    private fun shell(title: String, back: Boolean = true, nav: Boolean = true, b: LinearLayout) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        if (back) {
            val bar = row().apply {
                setPadding(d(18), d(8), d(18), d(6))
                addView(txt("‹", 34f).apply { setOnClickListener { show("tasks") } }, LinearLayout.LayoutParams(d(45), d(46)))
                addView(txt(title, 18f, white, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, d(46), 1f))
                addView(View(this@MainActivity), LinearLayout.LayoutParams(d(45), 1))
            }
            root.addView(bar)
        }
        val sc = ScrollView(this)
        sc.addView(b)
        root.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))
        if (nav) root.addView(navbar())
        setContentView(root)
    }

    private fun navbar(): View {
        val r = row().apply {
            setPadding(d(5), d(6), d(5), d(5))
            setBackgroundColor(navBg)
        }
        val icons = mapOf("home" to "⌂", "tasks" to "☑", "calendar" to "▦", "profile" to "♙")
        listOf("Inicio" to "home", "Tareas" to "tasks", "Calendario" to "calendar", "Perfil" to "profile").forEach { (n, s) ->
            val active = s == screen
            val v = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                addView(txt(icons[s]!!, 22f, if (active) red else muted).apply { gravity = Gravity.CENTER })
                addView(txt(n, 11f, if (active) red else muted).apply { gravity = Gravity.CENTER })
                setOnClickListener {
                    if (s == "calendar") { selDay = Dates.today(); month = now.get(Calendar.MONTH); year = now.get(Calendar.YEAR) }
                    show(s)
                }
            }
            r.addView(v, LinearLayout.LayoutParams(0, d(55), 1f))
        }
        return r
    }

    // =====================================================================
    // LOGIN / REGISTRO
    // =====================================================================
    private fun login() {
        val b = body(28)
        gap(b, 70)
        b.addView(txt("☑  TO DO List", 32f, white, true))
        gap(b, 7)
        b.addView(txt("Organiza tu vida,\nuna tarea a la vez.", 15f, muted))
        gap(b, 48)
        val userF = field("Usuario o correo electrónico")
        val passF = field("Contraseña", type = passType)
        b.addView(userF)
        gap(b, 8)
        b.addView(passF)
        gap(b, 10)
        b.addView(btn("Iniciar sesión", {
            // Sin trim ni cambios de mayúsculas: debe coincidir exactamente
            val u = db.login(userF.text.toString(), passF.text.toString())
            if (u == null) {
                toast("Usuario o contraseña incorrectos")
                passF.setText("")
            } else {
                user = u
                reload()
                filter = "Todas"
                show("home")
            }
        }, purple))
        b.addView(txt("¿No tienes cuenta? Regístrate", 13f, muted).apply {
            gravity = Gravity.CENTER
            setPadding(0, d(8), 0, d(8))
            setOnClickListener { show("register") }
        })
        shell("", false, false, b)
    }

    private fun register() {
        val b = body(28)
        b.addView(txt("‹", 32f).apply { setOnClickListener { show("login") } })
        gap(b, 20)
        b.addView(txt("☑ TO DO List", 23f, white, true))
        gap(b, 22)
        b.addView(txt("Crear cuenta", 27f, white, true))
        b.addView(txt("Regístrate para organizar tu vida, una tarea a la vez.", 14f, muted))
        gap(b, 24)
        val nameF = field("Nombre completo", type = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
        val mailF = field("Correo electrónico", type = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        val passF = field("Contraseña (mínimo 4 caracteres)", type = passType)
        val confF = field("Confirmar contraseña", type = passType)
        listOf(nameF, mailF, passF, confF).forEach { b.addView(it); gap(b, 8) }
        b.addView(btn("Registrarse", {
            val name = nameF.text.toString().trim()
            val mail = mailF.text.toString().trim()
            val pass = passF.text.toString()
            when {
                name.isEmpty() -> toast("Escribe tu nombre")
                !Patterns.EMAIL_ADDRESS.matcher(mail).matches() -> toast("Correo no válido")
                pass.length < 4 -> toast("La contraseña debe tener al menos 4 caracteres")
                pass != confF.text.toString() -> toast("Las contraseñas no coinciden")
                else -> {
                    val u = db.register(name, mail, pass)
                    if (u == null) toast("Ese correo ya está registrado")
                    else { user = u; reload(); filter = "Todas"; toast("Cuenta creada"); show("home") }
                }
            }
        }, purple))
        shell("", false, false, b)
    }

    // =====================================================================
    // INICIO / TAREAS
    // =====================================================================
    private fun addButton(top: Int = 0): TextView {
        val lp = LinearLayout.LayoutParams(d(54), d(54))
        lp.gravity = Gravity.RIGHT
        lp.topMargin = d(top)
        return txt("＋", 28f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = shape(purple, 50)
            setOnClickListener { editing = false; presetDate = Dates.today(); show("add") }
            layoutParams = lp
        }
    }

    private fun home() {
        val b = body()
        val u = user!!
        val today = Dates.today()
        b.addView(txt("☑ TO DO List", 20f, purple, true))
        gap(b, 8)
        b.addView(txt("Hola, ${u.name.substringBefore(" ")} 👋", 26f, white, true))
        b.addView(txt("Aquí tienes un resumen de tus tareas.", 13f, muted))
        gap(b, 16)
        val stats = row()
        listOf(
            "${tasks.count { !it.done }}\nPendientes" to purple,
            "${tasks.count { !it.done && it.date == today }}\nPara hoy" to Color.rgb(18, 67, 54),
            "${tasks.count { it.done }}\nCompletadas" to Color.rgb(46, 37, 82)
        ).forEach { (s, c) ->
            stats.addView(
                txt(s, 17f, Color.WHITE, true).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    background = shape(c, 17, edge)
                    setPadding(d(12), d(10), 0, d(10))
                },
                LinearLayout.LayoutParams(0, d(82), 1f).apply { rightMargin = d(5) }
            )
        }
        b.addView(stats)
        gap(b, 14)
        val hdr = row()
        hdr.addView(txt("Tareas de hoy", 17f, white, true), LinearLayout.LayoutParams(0, d(32), 1f))
        hdr.addView(txt("Ver todas ›", 13f, muted).apply { setOnClickListener { show("tasks") } })
        b.addView(hdr)
        val todays = tasks.filter { !it.done && it.date <= today }.take(3)
        if (todays.isEmpty()) b.addView(txt("No tienes tareas pendientes para hoy 🎉", 13f, muted).apply { setPadding(0, d(8), 0, d(8)) })
        todays.forEach { taskCard(b, it) }
        b.addView(addButton(15))
        shell("", false, true, b)
    }

    private fun taskCard(p: LinearLayout, t: Task) {
        val r = row().apply {
            background = shape(card, 15, edge)
            setPadding(d(12), d(10), d(10), d(10))
            setOnClickListener { selected = t; show("detail") }
        }
        r.addView(txt(if (t.done) "✓" else "◯", 22f, if (t.done) green else muted), LinearLayout.LayoutParams(d(32), -2))
        val whenTxt = Dates.pretty(t.date) + if (t.time.isNotBlank()) " · ${Dates.time(t.time)}" else ""
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(txt(t.title, 15f))
            addView(txt(if (t.done) "${t.category} · ${t.priority}" else "${t.priority}  ◷ $whenTxt", 12f, muted))
        }
        r.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(txt("›", 22f, muted))
        p.addView(r, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = d(9) })
    }

    private fun taskList() {
        val b = body()
        b.addView(txt("Mis tareas", 26f, white, true))
        gap(b, 9)
        val search = field("⌕  Buscar tareas...")
        b.addView(search)
        gap(b, 8)
        val filters = row()
        listOf("Todas", "Pendientes", "En proceso", "Completadas").forEach { f ->
            filters.addView(
                txt(f, 11f, if (filter == f) Color.WHITE else white).apply {
                    gravity = Gravity.CENTER
                    background = shape(if (filter == f) purple else card, 28, edge)
                    setOnClickListener { filter = f; show("tasks") }
                },
                LinearLayout.LayoutParams(0, d(38), 1f).apply { rightMargin = d(3) }
            )
        }
        b.addView(filters)
        b.addView(txt("Ver categorías  ›", 13f, purple).apply {
            setPadding(0, d(10), 0, d(5))
            setOnClickListener { show("categories") }
        })
        if (filter in cats) b.addView(txt("Categoría: $filter", 12f, muted))
        gap(b, 6)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val today = Dates.today()
        fun fill(q: String = "") {
            list.removeAllViews()
            val res = tasks.filter {
                it.title.contains(q, true) && when (filter) {
                    "Completadas" -> it.done
                    "Pendientes" -> !it.done
                    "En proceso" -> !it.done && it.date == today
                    "Todas" -> true
                    else -> it.category == filter
                }
            }
            if (res.isEmpty()) list.addView(txt("No hay tareas para mostrar", 13f, muted).apply { setPadding(0, d(10), 0, d(10)) })
            res.forEach { taskCard(list, it) }
        }
        fill()
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) { fill(s.toString()) }
            override fun afterTextChanged(e: Editable?) {}
        })
        b.addView(list)
        b.addView(addButton())
        shell("", false, true, b)
    }

    private fun detail() {
        val t = selected ?: tasks.firstOrNull() ?: run { show("tasks"); return }
        val b = body()
        val whenTxt = Dates.long(t.date) + if (t.time.isNotBlank()) ", ${Dates.time(t.time)}" else ""
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(card, 16, edge)
            setPadding(d(18), d(18), d(18), d(18))
            addView(txt(t.title, 18f, white, true))
            addView(txt(t.priority, 13f, red))
            gap(this, 14)
            addView(txt("▦  Fecha y hora\n     $whenTxt\n\n▣  Categoría\n     ${t.category}\n\n▤  Descripción\n     ${t.description.ifBlank { "Sin descripción" }}", 15f))
        }
        b.addView(box)
        gap(b, 12)
        b.addView(btn(if (t.done) "Marcar como pendiente" else "Marcar como completada", {
            t.done = !t.done
            db.updateTask(t)
            reload(); selected = tasks.firstOrNull { it.id == t.id }
            show("detail")
        }, purple))
        b.addView(btn("✎  Editar", { editing = true; show("add") }))
        b.addView(btn("▢  Eliminar", {
            AlertDialog.Builder(this)
                .setTitle("Eliminar tarea")
                .setMessage("¿Seguro que quieres eliminar \"${t.title}\"?")
                .setPositiveButton("Eliminar") { _, _ ->
                    db.deleteTask(t.id); reload(); selected = null; show("tasks")
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }, card, red))
        shell("Detalle de tarea", true, false, b)
    }

    private fun form() {
        val old = if (editing) selected else null
        val b = body()
        var date = old?.date ?: presetDate
        var time = old?.time ?: "19:00"
        var prio = old?.priority ?: "Alta"

        gap(b, 4)
        b.addView(txt("Título *", 13f, muted))
        val title = field("Título *", old?.title ?: "")
        b.addView(title)
        gap(b, 8)
        b.addView(txt("Descripción", 13f, muted))
        val desc = field("Descripción", old?.description ?: "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE)
        desc.minHeight = d(85)
        desc.gravity = Gravity.TOP
        b.addView(desc)
        gap(b, 10)
        b.addView(txt("Fecha y hora", 13f, muted))
        val dates = row()
        val dateBtn = btn("▦  ${Dates.pretty(date)}", {}, card, null, 46)
        val timeBtn = btn("◷  ${Dates.time(time)}", {}, card, null, 46)
        dateBtn.setOnClickListener {
            val p = date.split("-")
            DatePickerDialog(this, { _, y, m, day ->
                date = Dates.iso(y, m, day)
                dateBtn.text = "▦  ${Dates.pretty(date)}"
            }, p[0].toInt(), p[1].toInt() - 1, p[2].toInt()).show()
        }
        timeBtn.setOnClickListener {
            val p = time.split(":")
            TimePickerDialog(this, { _, h, m ->
                time = String.format("%02d:%02d", h, m)
                timeBtn.text = "◷  ${Dates.time(time)}"
            }, p[0].toInt(), p[1].toInt(), false).show()
        }
        dates.addView(dateBtn, LinearLayout.LayoutParams(0, d(46), 1f).apply { rightMargin = d(6) })
        dates.addView(timeBtn, LinearLayout.LayoutParams(0, d(46), 1f))
        b.addView(dates)
        gap(b, 8)
        b.addView(txt("Prioridad", 13f, muted))
        val ps = row()
        val prios = listOf("Alta", "Media", "Baja")
        fun paint() {
            prios.forEachIndexed { i, x ->
                val tv = ps.getChildAt(i) as TextView
                tv.background = shape(if (x == prio) red else card, 30, edge)
                tv.setTextColor(if (x == prio) Color.WHITE else white)
            }
        }
        prios.forEach { p ->
            ps.addView(
                txt(p, 14f, white, true).apply {
                    gravity = Gravity.CENTER
                    setOnClickListener { prio = p; paint() }
                },
                LinearLayout.LayoutParams(0, d(44), 1f).apply { rightMargin = d(5) }
            )
        }
        paint()
        b.addView(ps)
        gap(b, 10)
        b.addView(txt("Categoría", 13f, muted))
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, cats)
        sp.setSelection(cats.indexOf(old?.category ?: "Personal").coerceAtLeast(0))
        b.addView(sp)
        gap(b, 18)
        b.addView(btn("Guardar tarea", {
            val tt = title.text.toString().trim()
            if (tt.isEmpty()) {
                toast("El título es obligatorio")
            } else {
                val cat = sp.selectedItem.toString()
                if (old != null) {
                    old.title = tt; old.description = desc.text.toString().trim()
                    old.date = date; old.time = time; old.priority = prio; old.category = cat
                    db.updateTask(old)
                    reload(); selected = tasks.firstOrNull { it.id == old.id }
                    show("detail")
                } else {
                    db.insertTask(user!!.id, Task(0, tt, desc.text.toString().trim(), date, time, prio, cat))
                    reload()
                    // Si venía del calendario, regresar a ese día
                    if (screen == "add" && presetDate != Dates.today()) {
                        selDay = date
                        val p = date.split("-"); year = p[0].toInt(); month = p[1].toInt() - 1
                        show("calendar")
                    } else show("tasks")
                }
            }
        }, purple))
        shell(if (old == null) "Agregar tarea" else "Editar tarea", true, false, b)
    }

    private fun categories() {
        val b = body()
        val colors = listOf(card, Color.rgb(45, 99, 215), Color.rgb(199, 110, 8), Color.rgb(123, 52, 226), Color.rgb(19, 160, 75))
        val icons = listOf("▦", "▣", "♙", "♧", "🛒")
        val items = listOf("Todas" to tasks.size) + cats.map { c -> c to tasks.count { it.category == c } }
        items.forEachIndexed { i, p ->
            val fg = if (i == 0) white else Color.WHITE
            val r = row().apply {
                background = shape(colors[i], 15, if (i == 0) edge else 0)
                setPadding(d(15), d(13), d(15), d(13))
                addView(txt(icons[i], 20f, fg))
                addView(txt(p.first, 16f, fg, true), LinearLayout.LayoutParams(0, d(32), 1f).apply { leftMargin = d(12) })
                addView(txt("${p.second}", 15f, fg))
                setOnClickListener { filter = if (i == 0) "Todas" else p.first; show("tasks") }
            }
            b.addView(r, LinearLayout.LayoutParams(-1, d(62)).apply { bottomMargin = d(10) })
        }
        shell("Categorías", true, true, b)
    }

    // =====================================================================
    // CALENDARIO
    // =====================================================================
    private fun calendar() {
        val b = body()
        val today = Dates.today()

        // Encabezado con navegación de mes
        val nav = row()
        nav.addView(txt("‹", 27f).apply {
            setPadding(d(12), 0, d(12), 0)
            setOnClickListener { month--; if (month < 0) { month = 11; year-- }; show("calendar") }
        })
        nav.addView(txt("${Dates.months[month]} $year", 17f, white, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, d(42), 1f))
        nav.addView(txt("›", 27f).apply {
            setPadding(d(12), 0, d(12), 0)
            setOnClickListener { month++; if (month > 11) { month = 0; year++ }; show("calendar") }
        })
        b.addView(nav)

        val first = Calendar.getInstance().apply { clear(); set(year, month, 1) }
        val offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7 // semana inicia en lunes
        val grid = GridLayout(this).apply { columnCount = 7 }
        listOf("L", "M", "M", "J", "V", "S", "D").forEach {
            grid.addView(txt(it, 12f, muted).apply { gravity = Gravity.CENTER }, GridLayout.LayoutParams().apply { width = d(47); height = d(34) })
        }
        repeat(offset) {
            grid.addView(txt("", 12f), GridLayout.LayoutParams().apply { width = d(47); height = d(46) })
        }
        for (day in 1..first.getActualMaximum(Calendar.DAY_OF_MONTH)) {
            val iso = Dates.iso(year, month, day)
            val dayTasks = tasks.filter { it.date == iso }
            val isSel = iso == selDay
            val dot = when {
                dayTasks.isEmpty() -> ""
                else -> "●"
            }
            val dotColor = when {
                isSel -> Color.WHITE
                dayTasks.any { !it.done } -> red
                else -> green
            }
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                if (isSel) background = shape(purple, 40)
                else if (iso == today) background = shape(Color.TRANSPARENT, 40, purple)
                addView(txt("$day", 14f, if (isSel) Color.WHITE else white).apply { gravity = Gravity.CENTER })
                addView(txt(if (dot.isEmpty()) " " else dot, 7f, dotColor).apply { gravity = Gravity.CENTER })
                setOnClickListener { selDay = iso; show("calendar") }
            }
            grid.addView(cell, GridLayout.LayoutParams().apply { width = d(47); height = d(46) })
        }
        b.addView(grid, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
        b.addView(txt("Ir a hoy", 13f, purple).apply {
            gravity = Gravity.CENTER
            setPadding(0, d(8), 0, d(8))
            setOnClickListener { selDay = today; month = now.get(Calendar.MONTH); year = now.get(Calendar.YEAR); show("calendar") }
        }, LinearLayout.LayoutParams(-1, -2))

        gap(b, 6)
        b.addView(txt("Tareas del ${Dates.long(selDay)}", 16f, white, true))
        gap(b, 8)
        val dayTasks = tasks.filter { it.date == selDay }
        if (dayTasks.isEmpty()) b.addView(txt("No hay tareas este día", 13f, muted).apply { setPadding(0, d(4), 0, d(12)) })
        dayTasks.forEach { taskCard(b, it) }
        b.addView(btn("＋  Agregar tarea para este día", {
            editing = false
            presetDate = selDay
            show("add")
        }, purple))
        shell("", false, true, b)
    }

    // =====================================================================
    // PERFIL
    // =====================================================================
    private fun switchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val r = row().apply {
            background = shape(card, 14, edge)
            setPadding(d(15), 0, d(12), 0)
        }
        r.addView(txt(label, 15f, white, true).apply { gravity = Gravity.CENTER_VERTICAL }, LinearLayout.LayoutParams(0, d(50), 1f))
        r.addView(Switch(this).apply {
            isChecked = checked
            setOnCheckedChangeListener { _, v -> onChange(v) }
        })
        r.layoutParams = LinearLayout.LayoutParams(-1, d(50)).apply { bottomMargin = d(9) }
        return r
    }

    private fun profile() {
        val u = user!!
        val b = body()
        b.addView(txt("Perfil", 27f, white, true))
        gap(b, 15)
        b.addView(
            txt(u.name.trim().take(1).uppercase().ifEmpty { "?" }, 34f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                background = shape(purple, 50)
            },
            LinearLayout.LayoutParams(d(84), d(84)).apply { gravity = Gravity.CENTER_HORIZONTAL }
        )
        b.addView(txt(u.name, 19f, white, true).apply { gravity = Gravity.CENTER; setPadding(0, d(10), 0, 0) })
        b.addView(txt(u.email, 14f, muted).apply { gravity = Gravity.CENTER })
        b.addView(
            txt("${tasks.count { !it.done }} pendientes · ${tasks.count { it.done }} completadas", 12f, muted)
                .apply { gravity = Gravity.CENTER; setPadding(0, d(6), 0, d(18)) }
        )

        b.addView(btn("✎   Editar perfil", {
            val nameF = field("Nombre completo", u.name, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
            val mailF = field("Correo electrónico", u.email, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
            dialogForm("Editar perfil", listOf(nameF, mailF), "Guardar") {
                val n = nameF.text.toString().trim()
                val m = mailF.text.toString().trim()
                when {
                    n.isEmpty() -> { toast("Escribe tu nombre"); false }
                    !Patterns.EMAIL_ADDRESS.matcher(m).matches() -> { toast("Correo no válido"); false }
                    else -> {
                        db.updateProfile(u.id, n, m)
                        u.name = n; u.email = m
                        toast("Perfil actualizado")
                        show("profile")
                        true
                    }
                }
            }
        }))

        b.addView(switchRow("♧   Notificaciones", prefs.getBoolean("notif", true)) { v ->
            prefs.edit().putBoolean("notif", v).apply()
            toast(if (v) "Notificaciones activadas" else "Notificaciones desactivadas")
        })
        b.addView(switchRow("☾   Tema oscuro", dark) { v ->
            dark = v
            prefs.edit().putBoolean("dark", v).apply()
            applyPalette()
            show("profile")
        })

        b.addView(btn("♙   Cambiar contraseña", {
            val cur = field("Contraseña actual", type = passType)
            val nw = field("Nueva contraseña (mínimo 4 caracteres)", type = passType)
            val cf = field("Confirmar nueva contraseña", type = passType)
            dialogForm("Cambiar contraseña", listOf(cur, nw, cf), "Cambiar") {
                val n = nw.text.toString()
                when {
                    cur.text.isEmpty() -> { toast("Escribe tu contraseña actual"); false }
                    n.length < 4 -> { toast("La nueva contraseña debe tener al menos 4 caracteres"); false }
                    n != cf.text.toString() -> { toast("Las contraseñas no coinciden"); false }
                    !db.changePassword(u.id, cur.text.toString(), n) -> { toast("La contraseña actual es incorrecta"); false }
                    else -> { toast("Contraseña actualizada"); true }
                }
            }
        }))

        b.addView(btn("ⓘ   Ayuda", {
            AlertDialog.Builder(this)
                .setTitle("Ayuda")
                .setMessage(
                    "• Toca ＋ para agregar una tarea.\n" +
                        "• Toca una tarea para ver su detalle, editarla, completarla o eliminarla.\n" +
                        "• En Calendario, toca un día para ver sus tareas; el punto rojo indica tareas pendientes y el verde, completadas.\n" +
                        "• Desde Perfil puedes editar tus datos, cambiar la contraseña y el tema."
                )
                .setPositiveButton("Entendido", null)
                .show()
        }))

        b.addView(btn("⇥   Cerrar sesión", {
            user = null; tasks = mutableListOf(); selected = null
            show("login")
        }, card, red))
        shell("", false, true, b)
    }
}
